import React from "react";

class about extends React.Component {
  render() {
    const { match, t, i18n } = this.props;

    return (
      <div>
        <h2>Topics</h2>

      </div>
    );
  }
}

export default about;